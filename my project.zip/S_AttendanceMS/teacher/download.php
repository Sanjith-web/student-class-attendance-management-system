<?php
session_start();

if (!isset($_POST['type'])) {
    die("Invalid request");
}

$type = $_POST['type'];
$filename = "attendance_report.csv";

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=\"$filename\"");

$output = fopen("php://output", "w");

// Define headers based on report type
if ($type == "mass" || $type == "shortage") {
    fputcsv($output, ["S.No", "Reg. No.", "Name", "Department", "Total Days", "Present", "Absent", "Percentage"]);
} elseif ($type == "individual") {
    fputcsv($output, ["Field", "Value"]);
}

// Process "mass" and "shortage" report
if (($type == "mass" || $type == "shortage") && isset($_SESSION['mass_report'])) {
    $serial_no = 1;
    foreach ($_SESSION['mass_report'] as $row) {
        if (isset($row['total_classes'], $row['present_count'])) {
            $total_classes = $row['total_classes'];
            $present_count = $row['present_count'];
            $absent = $total_classes - $present_count;
            $percentage = ($total_classes > 0) ? round(($present_count / $total_classes) * 100, 2) : 0;

            // If "shortage" is selected, only include students with attendance < 75%
            if ($type == "shortage" && $percentage >= 75) {
                continue; // Skip students who have 75% or more attendance
            }

            fputcsv($output, [$serial_no, $row['st_id'], $row['st_name'], $row['st_dept'], $total_classes, $present_count, $absent, $percentage]);
            $serial_no++;
        }
    }
}

// Process "individual" report
elseif ($type == "individual" && isset($_SESSION['individual_report'])) {
    foreach ($_SESSION['individual_report'] as $row) {
        fputcsv($output, ["Name", $row['st_name']]);
        fputcsv($output, ["Department", $row['st_dept']]);
        fputcsv($output, ["Total Days", $row['total_classes']]);
    }
}
// Process "singleDay" report
elseif ($type == "singleDay" && isset($_SESSION['single_day_report'])) {
    $serial_no = 1;
    foreach ($_SESSION['single_day_report'] as $row) {
        fputcsv($output, [$serial_no, $row['st_name'], $row['st_id'], $row['st_dept'], $row['st_status']]);
        $serial_no++;
    }
}


fclose($output);
exit();

