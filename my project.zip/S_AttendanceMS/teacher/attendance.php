  <?php
ob_start();
session_start();

if ($_SESSION['name'] != 'oasis') {
    header('location: login.php');
    exit();
}

include('connect.php');

try {
    if (isset($_POST['att'])) {
        $course = isset($_POST['course']) ? $_POST['course'] : 'DefaultCourse';
        $dp = date('Y-m-d');

        if (!empty($course) && isset($_POST['st_status']) && isset($_POST['stat_id'])) {
            foreach ($_POST['st_status'] as $stat_id => $st_status) {
                $check_query = mysqli_query($conn, "SELECT * FROM attendance WHERE stat_id = '$stat_id' AND stat_date = '$dp'");

                if (mysqli_num_rows($check_query) == 0) {
                    $insert_query = mysqli_query($conn, "INSERT INTO attendance (stat_id, course, st_status, stat_date) 
                                                         VALUES ('$stat_id', '$course', '$st_status', '$dp')");
                    $att_msg = "Attendance Recorded Successfully.";
                } else {
                    $att_msg = "Attendance already recorded for today!";
                }
            }
        } else {
            $att_msg = "Error: Course or student status missing.";
        }
    }
} catch (Exception $e) {
    $error_msg = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Attendance</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
        .btn-group label {
            cursor: pointer;
        }
        .btn-group input[type="radio"] {
            display: none;
        }
        .btn-success.active, .btn-success:has(input:checked) {
            background-color: #5cb85c !important;
            color: white !important;
        }
        .btn-danger.active, .btn-danger:has(input:checked) {
            background-color: #d9534f !important;
            color: white !important;
        }
   table {
    background: url('images.jpeg') no-repeat center;
    background-size: cover;
}
</style>
    </style>
</head>
<body>

<header>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="students.php">Students</a>
        <a href="teachers.php">Faculties</a>
        <a href="attendance.php">Attendance</a>
        <a href="report.php">Report</a>
        <a href="../logout.php">Logout</a>
    </div>
</header>

<center>
    <div class="row">
        <div class="content">
            <h3>Attendance of <?php echo date('Y-m-d'); ?></h3>
            <br>

            <center>
                <p><?php if (isset($att_msg)) echo $att_msg; if (isset($error_msg)) echo $error_msg; ?></p>
            </center>

            <form action="" method="post" class="form-horizontal col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label>Enter Class ID</label>
                    <input type="text" name="whichbatch" id="input2" placeholder="Only class ID" required>
                </div>
                <input type="submit" class="btn btn-danger col-md-2 col-md-offset-5" value="Search" name="batch">
            </form>

            <div class="content"></div>
            <form action="" method="post">
           
                <input type="hidden" name="course" value="DefaultCourse">

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Reg. No.</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Class ID</th>
                            <th>Semester</th>
                            <th>Email</th>
                            <th>Status</th>
                        </thead>
                        </tr>
                    <tbody>
                    <?php
                    if (isset($_POST['batch'])) {
                        $batch = $_POST['whichbatch'];
                        $all_query = mysqli_query($conn, "SELECT * FROM students WHERE st_batch = '$batch' ORDER BY st_id ASC");
                        $serial_no = 1;
                         while ($data = mysqli_fetch_array($all_query)) {
                            $stat_id = $data['st_id'];
                            $dp = date('Y-m-d');
                            $attendance_query = mysqli_query($conn, "SELECT st_status FROM attendance WHERE stat_id = '$stat_id' AND stat_date = '$dp'");
                            $attendance_data = mysqli_fetch_assoc($attendance_query);
                            $status = isset($attendance_data['st_status']) ? $attendance_data['st_status'] : "Not Marked";
                            echo "<tr>
                                    <td>{$serial_no}</td>
                                    <td>{$data['st_id']} <input type='hidden' name='stat_id[]' value='{$data['st_id']}'> </td>
                                    <td>{$data['st_name']}</td>
                                    <td>{$data['st_dept']}</td>
                                    <td>{$data['st_batch']}</td>
                                    <td>{$data['st_sem']}</td>
                                    <td>{$data['st_email']}</td>
                                    <td>";
                            if ($status == "Not Marked") {
                                echo "<div class='btn-group' data-toggle='buttons'>
                                          <label class='btn btn-success active'> 
                                              <input type='radio' name='st_status[{$stat_id}]' value='Present' required checked> Present
                                          </label>
                                          <label class='btn btn-danger'> 
                                              <input type='radio' name='st_status[{$stat_id}]' value='Absent' required> Absent
                                          </label>
                                      </div>";
                            } else {
                                echo "<span class='status'>$status</span>";
                            }

                            echo "</td></tr>";
                            $serial_no++;
                        }
                    }
                    ?>
                    </tbody>
                </table>
                <center>
                    <br>
                    <input type="submit" class="btn btn-primary col -md-2 col-md-offset-10" value="Save Attendance" name="att">
                </center>
            </form>
        </div>
    </div>
</center>

<script>
    $(document).ready(function(){
        $(".btn-group input[type='radio']").each(function() {
            if ($(this).is(":checked")) {
                $(this).parent().addClass("active");
            }
        });

        $(".btn-group input[type='radio']").change(function(){
            var parent = $(this).closest(".btn-group");
            parent.find("label").removeClass("active btn-success btn-danger");

            if ($(this).val() === "Present") {
                $(this).parent().addClass("active btn-success");
            } else if ($(this).val() === "Absent") {
                $(this).parent().addClass("active btn-danger");
            }[]
        });
    });
</script>

</body>
</html>