<?php
session_start();
include('connect.php');

if (isset($_POST['save_attendance'])) {
    $dp = date('Y-m-d'); // Current date

    if (isset($_POST['st_status']) && isset($_POST['stat_id'])) {
        foreach ($_POST['st_status'] as $stat_id => $st_status) {
            // Check if attendance already exists for the day
            $check_query = mysqli_query($conn, "SELECT * FROM attendance WHERE stat_id = '$stat_id' AND stat_date = '$dp'");

            if (mysqli_num_rows($check_query) == 0) {
                // Insert new attendance record
                mysqli_query($conn, "INSERT INTO attendance (stat_id, st_status, stat_date) VALUES ('$stat_id', '$st_status', '$dp')");
            } else {
                // Update existing attendance record
                mysqli_query($conn, "UPDATE attendance SET st_status = '$st_status' WHERE stat_id = '$stat_id' AND stat_date = '$dp'");
            }
        }
        $_SESSION['success_message'] = "Attendance Recorded Successfully!";
    } else {
        $_SESSION['error_message'] = "Error: Please select attendance for all students!";
    }
}

// Redirect back to attendance page
header('location: attendance.php');
exit();
?>
