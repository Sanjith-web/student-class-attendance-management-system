<?php

ob_start();
session_start();

if($_SESSION['name']!='oasis') {
    header('location: ../index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Attendance Management System</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/main.css">
<style>
    table {
        background: url('images.jpeg') no-repeat center;
        background-size: cover;
    }

    /* Style for the "About" content */
    #aboutContent {
        display: none;
        margin-top: 20px;
        padding: 20px;
        border: 2px solid #ccc;
        border-radius: 8px;
        background-color: rgba(255, 255, 255, 0.9);
        width: 50%;
        text-align: left;
    }
    
</style>
</head>
<body>

<header>

  <div class="navbar">
    <a href="index.php" style="text-decoration:none;">Home</a>
    <a href="students.php" style="text-decoration:none;">Students</a>
    <a href="teachers.php" style="text-decoration:none;">Faculties</a>
    <a href="attendance.php" style="text-decoration:none;">Attendance</a>
    <a href="report.php" style="text-decoration:none;">Report</a>
    <a href="javascript:void(0);" class="about-btn" onclick="toggleAboutSection()">About</a>
    <a href="../logout.php" style="text-decoration:none;">Logout</a>
  </div>

</header>
 <center>
<div class="row">
    <div class="content">
        <!-- The "About" content section -->
        <div id="aboutContent">
            <CEnter><h3>About the class id for BCA </h3></CEnter>
            <p><strong>Class ID:</strong> 1111</p>
            <p><strong>Department:</strong> III BCA A</p>
            -----------------------------------------------------
            <p><strong>Class ID:</strong> 1112</p>
            <p><strong>Department:</strong> III BCA B</p>
            -----------------------------------------------------
        </div>
    </div>
</div>

</center>

<script>
    // Function to toggle visibility of the "About" content
    function toggleAboutSection() {
        var aboutContent = document.getElementById("aboutContent");
        if (aboutContent.style.display === "none" || aboutContent.style.display === "") {
            aboutContent.style.display = "block";
        } else {
            aboutContent.style.display = "none";
        }
    }
</script>

</body>
</html>
