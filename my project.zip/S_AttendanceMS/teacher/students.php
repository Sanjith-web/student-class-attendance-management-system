<?php
ob_start();
session_start();

if (!isset($_SESSION['name']) || $_SESSION['name'] != 'oasis') {
    header('location: login.php');
    exit();
}

include('connect.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Details </title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="styles.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>table {
    background: url('images.jpeg') no-repeat center;
    background-size: cover;
}
</style>
</head>
<body>

<header>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="students.php">Students</a>
        <a href="teachers.php">Faculties</a>
        <a href="attendance.php">Attendance</a>
        <a href="report.php">Report</a>
        <a href="../logout.php">Logout</a>
    </div>
</header>
<center>
<div class="container">
    <h3>Student List</h3>
    <br>
    <form method="post">
        <label>Class id:</label>
        <input type="text" name="sr_batch" placeholder="Enter Class id" required>
        <input type="submit" name="sr_btn" class="btn btn-danger" value="Search">
    </form>
    <br>

    <table class="table table-bordered">
    <thead>
        <tr>
            <th>Serial No.</th>
            <th>Registration No.</th>
            <th>Name</th>
            <th>Department</th>
            <th>Class id</th>
            <th>Semester</th>
            <th>Email</th>
        </tr>
    </thead>
    <tbody>

    <?php
    if (isset($_POST['sr_btn'])) {
        $srbatch = trim($_POST['sr_batch']); // Remove extra spaces

        // Fetch student data
        $stmt = $conn->prepare("SELECT st_id, st_name, st_dept, st_batch, st_sem, st_email FROM students WHERE st_batch = ? ORDER BY st_id ASC");

        if (!$stmt) {
            die("<tr><td colspan='7' class='text-danger'>Query preparation failed: " . $conn->error . "</td></tr>");
        }

        $stmt->bind_param("s", $srbatch);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $serial = 1; // Initialize serial number
            while ($data = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $serial++ . "</td>
                    <td>{$data['st_id']}</td>
                    <td>{$data['st_name']}</td>
                    <td>{$data['st_dept']}</td>
                    <td>{$data['st_batch']}</td>
                    <td>{$data['st_sem']}</td>
                    <td>{$data['st_email']}</td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='text-danger'>No students found for batch $srbatch.</td></tr>";
        }

        $stmt->close();
    }
    ?>

    </tbody>
</table>

</div>
</center>

</body>
</html>
