-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2021 at 08:50 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attmgsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`username`, `password`, `email`, `fname`, `phone`, `type`) VALUES
('admin', 'admin', 'admin@gmail.com', 'admin', '2147483647', 'admin'),
('student', 'student', 'christine@gmail.com', 'Christine', '4512224500', 'student'),
('teacher', 'teacher', 'kevinm@gmail.com', 'Kevin Moore', '1247778540', 'teacher');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `stat_id` varchar(20) NOT NULL,
  `course` varchar(20) NOT NULL,
  `st_status` varchar(10) NOT NULL,
  `stat_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`stat_id`, `course`, `st_status`, `stat_date`) VALUES
('1', 'algo', 'Present', '2018-11-14');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `st_id` varchar(30) NOT NULL,
  `course` varchar(30) NOT NULL,
  `st_status` varchar(30) NOT NULL,
  `st_name` varchar(30) NOT NULL,
  `st_dept` varchar(30) NOT NULL,
  `st_batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `st_id` varchar(20) NOT NULL,
  `st_name` varchar(20) NOT NULL,
  `st_dept` varchar(20) NOT NULL,
  `st_batch` int(4) NOT NULL,
  `st_sem` int(11) NOT NULL,
  `st_email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`st_id`, `st_name`, `st_dept`, `st_batch`, `st_sem`, `st_email`) VALUES
('22UBCA001', 'AKASH V', 'BCA', 1111, 6, 'akash@gmail.com'),
('22UBCA003', 'ANADHA KRISHNAN R', 'BCA', 1111, 6, 'anadha@gmail.com'),
('22UBCA005', 'ASHIK NIRANJAN A', 'BCA', 1111, 6, 'ashik@gmail.com'),
('22UBCA008', 'CHANDRU A', 'BCA', 1111, 6, 'chandru@gmail.com'),
('22UBCA013', 'HARIHARAN G', 'BCA', 1111, 6, 'hari@gmail.com'),
('22UBCA015', 'ISHIVA N', 'BCA', 1111, 6, 'ishiva@gmail.com'),
('22UBCA088', 'JAYAKUMAR T', 'BCA', 1111, 6, 'jayakumar@gmail.com'),
('22UBCA018', 'KADAL VANNAN C.M', 'BCA', 1111, 6, 'kadal@gmail.com'),
('22UBCA019', 'KAMALAN U', 'BCA', 1111, 6, 'kamalan@gmail.com'),
('22UBCA021', 'LINGESH V', 'BCA', 1111, 6, 'lingesh@gmail.com'),
('22UBCA023', 'MOHAMED NAYEEM K', 'BCA', 1111, 6, 'mohamed@gmail.com'),
('22UBCA026', 'NANDHA KUMAR A', 'BCA', 1111, 6, 'nandha@gmail.com'),
('22UBCA028', 'NIRESH M ', 'BCA', 1111, 6, 'niresh@gmail.com'),
('22UBCA029', 'PRABAKARAN P', 'BCA', 1111, 6, 'praba@gmail.com'),
('22UBCA030', 'RAJESH K ', 'BCA', 1111, 6, 'rajesh@gmail.com'),
('22UBCA033', 'SANJITH K ', 'BCA', 1111, 6, 'sanjith@gmail.com'),
('22UBCA034', 'SANTHOSH KUMAR R ', 'BCA', 1111, 6, 'santhosh@gmail.com'),
('22UBCA037', 'SATHISH KUMAR R ', 'BCA', 1111, 6, 'sathish@gmail.com'),
('22UBCA038', 'SATHYA SAI K ', 'BCA', 1111, 6, 'sathya@gmail.com'),
('22UBCA039', 'SRIDHAR C ', 'BCA', 1111, 6, 'sri@gmail.com'),
('22UBCA044', 'SUMIL A ', 'BCA', 1111, 6, 'sumil@gmail.com'),
('22UBCA045', 'SURESH G ', 'BCA', 1111, 6, 'suresh@gmail.com'),
('22UBCA046', 'SUTHANANTHAN S ', 'BCA', 1111, 6, 'sutha@gmail.com'),
('22UBCA050', 'VENKATARAMANAN B  ', 'BCA', 1111, 6, 'venkat@gmail.com'),
('22UBCA053', 'VISHNU P ', 'BCA', 1111, 6, 'vishnu@gmail.com'),
('22UBCA002', ' AJAIKUMAR G', 'BCA', 1112, 6, 'ajaikumar@gmail.com'),
('22UBCA004', ' ARUNACHALAM S', 'BCA', 1112, 6, 'arunachalam@gmail.com'),
('22UBCA006', 'BALAJI E ', 'BCA', 1112, 6, 'balaji@gmail.com'),
('22UBCA007', 'BOOBALAN L ', 'BCA', 1112, 6, 'boobalan@gmail.com'),
('22UBCA010', 'GOPINATHAN C ', 'BCA', 1112, 6, 'gobi@gmail.com'),
('22UBCA011', 'GOWTHAM A ', 'BCA', 1112, 6, 'gowtham@gmail.com'),
('22UBCA012', 'GUBENDRAVASAN L ', 'BCA', 1112, 6, 'guben@gmail.com'),
('22UBCA014', ' HARISHNARAYANAN S', 'BCA', 1112, 6, 'harish@gmail.com'),
('22UBCA016', 'JANARTHANAN C ', 'BCA', 1112, 6, 'jana@gmail.com'),
('22UBCA020', 'KAMLESH R ', 'BCA', 1112, 6, 'kamalesh@gmail.com'),
('22UBCA022', ' MADHANKUMAR A', 'BCA', 1112, 6, 'madhan@gmail.com'),
('22UBCA024', 'MOTHIPKUMAR J ', 'BCA', 1112, 6, 'mothip@gmail.com'),
('22UBCA025', 'MOULISHWARAN V ', 'BCA', 1112, 6, 'molish@gmail.com'),
('22UBCA027', 'NAVEENKUMAR  ', 'BCA', 1112, 6, 'naveen@gmail.com'),
('22UBCA031', 'SACHINGANDHI K ', 'BCA', 1112, 6, 'sachin@gmail.com'),
('22UBCA032', 'SANJAY M ', 'BCA', 1112, 6, 'sanjai@gmail.com'),
('22UBCA035', 'SANTHOSHKUMAR R ', 'BCA', 1112, 6, 'santhosh@gmail.com'),
('22UBCA036', 'SARAVANAN E ', 'BCA', 1112, 6, 'saravanan@gmail.com'),
('22UBCA040', 'SRIRAM R ', 'BCA', 1112, 6, 'sriram@gmail.com'),
('22UBCA041', 'SRISAKTHI J ', 'BCA', 1112, 6, 'srisakthi@gmail.com'),
('22UBCA042', 'SUBASH A ', 'BCA', 1112, 6, 'subash@gmail.com'),
('22UBCA043', 'SUDHAKAR N ', 'BCA', 1112, 6, 'sudhakar@gmail.com'),
('22UBCA048', 'THIRUMALAI P ', 'BCA', 1112, 6, 'thirumalai@gmail.com'),
('22UBCA049', 'VENGATESH S ', 'BCA', 1112, 6, 'vengatesh@gmail.com'),
('22UBCA051', 'VENKATESAN S ', 'BCA', 1112, 6, 'venkatesh@gmail.com'),
('22UBCA052', 'VIGNESH S ', 'BCA', 1112, 6, 'vignesh@gmail.com');



-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `tc_id` varchar(20) NOT NULL,
  `tc_name` varchar(20) NOT NULL,
  `tc_dept` varchar(20) NOT NULL,
  `tc_email` varchar(30) NOT NULL,
  `tc_course` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`tc_id`, `tc_name`, `tc_dept`, `tc_email`, `tc_course`) VALUES
('1', 'PANDIYARAJ', 'BCA', 'pandi@gmail.com', '.NET'),
('2', 'SRIDHARAN', 'BCA', 'sridharan@gmail.com', 'WEB DEVELOPMENT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD KEY `stat_id` (`stat_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`st_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`tc_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`stat_id`) REFERENCES `students` (`st_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
