
	<?php

if(isset($_POST['login']))
{
	try{
		if(empty($_POST['username'])){
			throw new Exception("Username is required!");
		}
		if(empty($_POST['password'])){
			throw new Exception("Password is required!");
		}

		include ('connect.php');
		
		$row=0;
		$result=mysqli_query($conn,"SELECT * from admininfo where username='$_POST[username]' and password='$_POST[password]' and type='$_POST[type]'");
		$row=mysqli_num_rows($result);

		if($row>0){
			session_start();
			$_SESSION['name']="oasis";

			switch($_POST["type"]){
				case 'teacher': header('location: teacher/index.php'); break;
				case 'student': header('location: student/index.php'); break;
				case 'admin': header('location: admin/index.php'); break;
			}
			exit();
		}
		else{
			throw new Exception("Username, Password, or Role is wrong, try again!");
		}

	}
	catch(Exception $e){
		$error_msg=$e->getMessage();
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Attendance Management System</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<style>
		body {
			background: url('9.jpg') no-repeat center center fixed;
			background-size: cover;
		}
		.login-box {
			background: rgba(0, 0, 0, 0.6);
			border: 2px solid rgba(255, 255, 255, 0.8);
			border-radius: 20px;
			padding: 20px;
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
			max-width: 600px;
			margin: 50px auto;
			color: white;
			display: none; /* Hide initially */
		}
		.btn-success {
			background-color: #28a745;
			border-color: #218838;
			font-weight: bold;
		}
		.login-btn-container {
        text-align: center;
    }

    .btn-login {
        padding: 30px 50px;
        font-size: 30px;
        background-color:rgb(15, 16, 15);
        color: white;
        border: none;
        border-radius: 10px;
        cursor: pointer;
    }

    .btn-login:hover {
        background-color: #218838;
    }
	</style>
	<script>
		function showLogin() {
			document.getElementById('loginForm').style.display = 'block';
		}
	</script>
</head>
<body>
	<center>
		<button class="btn-login" onclick="showLogin()">Open Login Page</button>

		<?php if(isset($error_msg)) echo "<p style='color:red;'>$error_msg</p>"; ?>

		<div id="loginForm" class="login-box">
			<h2><u>Login</u></h2>
			<form method="post" class="form-horizontal">
				<div class="form-group">
					<label class="col-sm-3 control-label">Username</label>
					<div class="col-sm-7">
						<input type="text" name="username" class="form-control" placeholder="Your Username" />
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Password</label>
					<div class="col-sm-7">
						<input type="password" name="password" class="form-control" placeholder="Your Password" />
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Login As:</label>
					<div class="col-sm-6">
						<label><input type="radio" name="type" value="student" checked> Student</label>
						<label><input type="radio" name="type" value="teacher"> Teacher</label>
						<label><input type="radio" name="type" value="admin"> Admin</label>
					</div>
				</div>
				<input type="submit" class="btn btn-success" value="Login" name="login" />
								<p><strong><a href="reset.php" style="color: white;"><b>Reset Password</b></a></strong></p>
			</form>
		</div>
	</center>
</body>
</html>